<?php

return [
    'name' => 'Installer'
];
