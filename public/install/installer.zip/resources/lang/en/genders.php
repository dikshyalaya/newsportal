<?php

return [
    'genderType' => [
        \App\Enums\GenderType::Male => 'Male',
        \App\Enums\GenderType::Female => 'Female',
        \App\Enums\GenderType::Other => 'Other',
    ],
];
