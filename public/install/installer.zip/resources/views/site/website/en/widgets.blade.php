<div class="sg-widget">
    <h3 class="widget-title">Popular Posts</h3>

    <ul class="global-list">
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/like-%27armageddon%27:-farmers-reeling-in-aftermath-of-a-terrifying-firestorm-they-had-no-hope-of-beating">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125612_small_123x83_10.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Like 'Armageddon': Farmers reeling in aftermath of a terrifying firestorm they had no hope of beating">
                    </a>
    </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/like-%27armageddon%27:-farmers-reeling-in-aftermath-of-a-terrifying-firestorm-they-had-no-hope-of-beating"> <p>Like &#039;Armageddon&#039;: Farmer...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140344_small_123x83_11.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Duchess replied, in a hurry to get very tired of this. I vote the young man said, 'And your hair has become very.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27"> <p>Duchess replied, in a hur...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/why-are-flying-foxes-turning-up-in-strange-places">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125617_small_123x83_33.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Why are flying foxes turning up in strange places?">
                    </a>
    </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/why-are-flying-foxes-turning-up-in-strange-places"> <p>Why are flying foxes turn...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140134_small_123x83_32.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Five! Always lay the blame on others!' 'YOU'D better not talk!' said Five. 'I heard every word you fellows were.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17"> <p>Five! Always lay the blam...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
            </ul>
</div>
                    <div class="sg-widget widget-social">
    <h3 class="widget-title">Stay Connected</h3>
    <div class="sg-socail">
        <ul class="global-list">
                            <li class="facebook"><a href="#" style="background:#056ED8" name="Facebook"><span style="background:#0061C2"><i class="fa fa-facebook" aria-hidden="true"></i></span>Facebook</a></li>
                            <li class="facebook"><a href="#" style="background:#E50017" name="Youtube"><span style="background:#FE031C"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>Youtube</a></li>
                            <li class="facebook"><a href="#" style="background:#349AFF" name="Twitter"><span style="background:#2391FF"><i class="fa fa-twitter" aria-hidden="true"></i></span>Twitter</a></li>
                            <li class="facebook"><a href="#" style="background:#349affd9" name="Linkedin"><span style="background:#349AFF"><i class="fa fa-linkedin" aria-hidden="true"></i></span>Linkedin</a></li>
                            <li class="facebook"><a href="#" style="background:#4BA3FC" name="Skype"><span style="background:#4ba3fcd9"><i class="fa fa-skype" aria-hidden="true"></i></span>Skype</a></li>
                            <li class="facebook"><a href="#" style="background:#c2000dd9" name="Pinterest"><span style="background:#C2000D"><i class="fa fa-pinterest-square" aria-hidden="true"></i></span>Pinterest</a></li>
                    </ul>
    </div>
</div><!-- /.sg-widget -->
                    <div class="sg-widget">
    <h3 class="widget-title">Newsletter</h3>
    <div class="widget-newsletter text-center">
        <div class="icon">
            <i class="fa fa-envelope-o" aria-hidden="true"></i>
        </div>
        <p>Subscribe to our mailing list to get the new updates!</p>

        <form action="https://ohno-news-and-magazine-cms-laravel.dev/newsletter/subscribe" class="tr-form" method="POST">
            <input type="hidden" name="_token" value="IYbAGLCSYGhMh6iFC01R5UvTlgtt01uj4tg5gRg3">            <label for="news" class="d-none">Newsletter</label>
            <input name="email" id="news" type="email" class="form-control" placeholder="Email Address" required>
            <button type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i><span class="d-none">Email Address</span></button>
        </form>
    </div>
</div>
                                        <div class="sg-widget">
    <h3 class="widget-title">Recent Posts</h3>
    <div class="row">
                    <div class="col-md-6">
                <div class="sg-post small-post">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/temporibus-aut-sequi-voluptatem-ut-blanditiis-et-ut-ullam-30">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140419_medium_255x175_12.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="I don't know where Dinn may be,' said the cook. The King looked anxiously round, to make personal remarks,' Alice said.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                    <div class="entry-content">
                        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/temporibus-aut-sequi-voluptatem-ut-blanditiis-et-ut-ullam-30"><p>I don't know where Dinn m...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li> <a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="col-md-6">
                <div class="sg-post small-post">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/iusto-delectus-incidunt-aperiam-et-29">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140408_medium_255x175_28.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Alice took up the fan and two or three of her own courage. 'It's no use in saying anything more till the puppy's bark.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                    <div class="entry-content">
                        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/iusto-delectus-incidunt-aperiam-et-29"><p>Alice took up the fan and...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li> <a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="col-md-6">
                <div class="sg-post small-post">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140353_medium_255x175_40.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Alice to herself. Imagine her surprise, when the White Rabbit, with a round face, and large eyes full of soup.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                    <div class="entry-content">
                        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28"><p>Alice to herself. Imagine...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li> <a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="col-md-6">
                <div class="sg-post small-post">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140344_medium_255x175_33.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Duchess replied, in a hurry to get very tired of this. I vote the young man said, 'And your hair has become very.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                    <div class="entry-content">
                        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27"><p>Duchess replied, in a hur...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                <li> <a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            </div>
</div>
                    <div class="sg-widget categories-widget">
    <h3 class="widget-title">Categories</h3>
    <ul class="global-list">
                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/world">World <span>(9)</span></a></li>
                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/science">Science <span>(10)</span></a></li>
                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style <span>(10)</span></a></li>
                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/rss-news">RSS News <span>(15)</span></a></li>
            </ul>
</div>
                    <div class="sg-widget">
        <h3 class="widget-title">Recommended Posts</h3>

        <div class="sg-post featured-post">
            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/et-aperiam-placeat-et-ea-sint-veritatis-25">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140320_medium_358x215_9.webp"
                     class="img-fluid" alt="Rabbit in a low trembling voice, 'Let us get to twenty at that rate! However, the Multiplication Table doesn't.">
                    </a>
    </div>
            <div class="video-icon large-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg" alt="video-icon">
        </div>
    </div>
            <div class="entry-content absolute">
                <div class="category">
                    <ul class="global-list">
                                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                            </ul>
                </div>
                <h2 class="entry-title">
                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/et-aperiam-placeat-et-ea-sint-veritatis-25">Rabbit in a low trembling voice, &#039;Let us get to twenty at that rate! However, the Multiplication Tab...</a>
                </h2>
                <div class="entry-meta">
                    <ul class="global-list">
                        <li>Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <ul class="global-list">
                                                                            <li>
                        <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/in-id-molestiae-numquam-culpa-et-non-omnis-26">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140334_small_123x83_14.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Alice. 'Why, you don't know what you had been for some time in silence: at last she stretched her arms folded.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/in-id-molestiae-numquam-culpa-et-non-omnis-26"><p>Alice. &#039;Why, you don&#039;t kn...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                                                                <li>
                        <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140344_small_123x83_11.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Duchess replied, in a hurry to get very tired of this. I vote the young man said, 'And your hair has become very.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27"><p>Duchess replied, in a hur...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                                                                <li>
                        <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140353_small_123x83_23.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Alice to herself. Imagine her surprise, when the White Rabbit, with a round face, and large eyes full of soup.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28"><p>Alice to herself. Imagine...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                                    </ul>
    </div>
                    <div class="sg-widget categories-widget">
    <h3 class="widget-title">Tags</h3>
    <div class="tagcloud">
                    <a class="text-capitalize" href="https://ohno-news-and-magazine-cms-laravel.dev/tags/politics">politics</a>
                    <a class="text-capitalize" href="https://ohno-news-and-magazine-cms-laravel.dev/tags/world">world</a>
            </div>
</div>
                    <div class="sg-widget">
        <h3 class="widget-title">Featured Posts</h3>

        <div class="sg-post featured-post">
            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/repellat-ea-commodi-possimus-sit-15">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140106_medium_358x215_30.webp"
                     class="img-fluid" alt="As she said this, she came upon a little pattering of feet in a trembling voice, '--and I hadn't drunk quite so much!'.">
                    </a>
    </div>
            <div class="video-icon large-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg" alt="video-icon">
        </div>
    </div>
            <div class="entry-content absolute">
                <div class="category">
                    <ul class="global-list">
                                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/science">Science</a></li>
                                            </ul>
                </div>
                <h2 class="entry-title">
                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/repellat-ea-commodi-possimus-sit-15">As she said this, she came upon a little pattering of feet in a trembling voice, &#039;--and I hadn&#039;t dru...</a>
                </h2>
                <div class="entry-meta">
                    <ul class="global-list">
                        <li>Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <ul class="global-list">
                                                                            <li>
                        <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/autem-sunt-similique-et-pariatur-optio-16">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140118_small_123x83_44.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="White Rabbit interrupted: 'UNimportant, your Majesty means, of course,' he said in a loud, indignant voice, but she.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/autem-sunt-similique-et-pariatur-optio-16"><p>White Rabbit interrupted:...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                                                                <li>
                        <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140134_small_123x83_32.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Five! Always lay the blame on others!' 'YOU'D better not talk!' said Five. 'I heard every word you fellows were.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17"><p>Five! Always lay the blam...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                                                                <li>
                        <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/architecto-omnis-fuga-est-laudantium-ut-sint-eaque-18">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140155_small_123x83_47.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="I can guess that,' she added aloud. 'Do you play croquet with the bread-and-butter getting so used to it as well look.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/architecto-omnis-fuga-est-laudantium-ut-sint-eaque-18"><p>I can guess that,&#039; she ad...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li class="d-sm-none d-md-none d-lg-block">Post By<a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </li>
                                    </ul>
    </div>
    