<div class="sg-widget">
    <h3 class="widget-title">منشورات شائعة</h3>

    <ul class="global-list">
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D8%A7%D9%84%D9%85%D9%88%D8%AC%D9%88%D8%AF-%D8%A7%D9%84%D9%88%D8%A7%D8%AC%D8%A8-%D8%A7%D9%84%D9%88%D8%AC%D9%88%D8%AF%D8%9B-%D9%88%D9%84%D8%A7-%D8%A7%D8%AA%D8%B5%D9%84-%D8%A8%D9%87%D8%9B-%D9%88%D9%84%D8%A7-%D8%B3%D9%85%D8%B9-%D8%B9%D9%86%D9%87%D8%9B-%D9%81%D9%87%D8%B0%D8%A7-%D8%A5%D8%B0%D8%A7-1">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140237_small_123x83_17.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="وما زال الوصول إلى ذلك الشيء ينبغي إن يكون سبباً في فساد حاله وعائقاً بينه وبين أمله. واما حي بن يقظان في تعليمهم وبث.">
                    </a>
    </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D8%A7%D9%84%D9%85%D9%88%D8%AC%D9%88%D8%AF-%D8%A7%D9%84%D9%88%D8%A7%D8%AC%D8%A8-%D8%A7%D9%84%D9%88%D8%AC%D9%88%D8%AF%D8%9B-%D9%88%D9%84%D8%A7-%D8%A7%D8%AA%D8%B5%D9%84-%D8%A8%D9%87%D8%9B-%D9%88%D9%84%D8%A7-%D8%B3%D9%85%D8%B9-%D8%B9%D9%86%D9%87%D8%9B-%D9%81%D9%87%D8%B0%D8%A7-%D8%A5%D8%B0%D8%A7-1"> <p>وما زال الوصول إلى ذلك ال...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">نشر بواسطة<a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D9%88%D8%A5%D8%B2%D8%A7%D9%84%D8%A9-%D8%A7%D9%84%D8%AF%D9%86%D8%B3-%D9%88%D8%A7%D9%84%D8%B1%D8%AC%D8%B3-%D8%B9%D9%86-%D8%AC%D8%B3%D9%85%D9%87-%D9%88%D8%A7%D9%84%D8%A7%D8%BA%D8%AA%D8%B3%D8%A7%D9%84-%D8%A8%D8%A7%D9%84%D9%85%D8%A7%D8%A1-%D9%81%D9%8A-%D8%A3%D9%83%D8%AB%D8%B1-%D9%85%D8%A7-2">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140257_small_123x83_2.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="لا تدرك إلا جسماً من الأجسام، ثم حركت يدك، فان ذلك كالمعتذر. واما تمام خبره - فسأتلوه عليك إن شاء الله تعالى: وهو انه.">
                    </a>
    </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D9%88%D8%A5%D8%B2%D8%A7%D9%84%D8%A9-%D8%A7%D9%84%D8%AF%D9%86%D8%B3-%D9%88%D8%A7%D9%84%D8%B1%D8%AC%D8%B3-%D8%B9%D9%86-%D8%AC%D8%B3%D9%85%D9%87-%D9%88%D8%A7%D9%84%D8%A7%D8%BA%D8%AA%D8%B3%D8%A7%D9%84-%D8%A8%D8%A7%D9%84%D9%85%D8%A7%D8%A1-%D9%81%D9%8A-%D8%A3%D9%83%D8%AB%D8%B1-%D9%85%D8%A7-2"> <p>لا تدرك إلا جسماً من الأج...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">نشر بواسطة<a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D9%85%D8%AC%D8%A7%D9%87%D8%AF%D8%AA%D9%87-%D9%87%D8%B0%D9%87-%D8%B1%D8%A8%D9%85%D8%A7-%D9%83%D8%A7%D9%86%D8%AA-%D8%AA%D8%BA%D9%8A%D8%A8-%D8%B9%D9%86-%D8%B0%D9%83%D8%B1%D9%87-%D9%88%D9%81%D9%83%D8%B1%D9%87-%D8%AC%D9%85%D9%8A%D8%B9-%D8%A7%D9%84%D8%A3%D8%B4%D9%8A%D8%A7%D8%A1-%D8%A5%D9%84%D8%A7-3">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140304_small_123x83_26.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="على خلافه. وذلك أنه قال: أما الجسم السماوي فهو متناه من الجهة فهو في حالتي تفريقه وجمعه شيء واحد، وأنه لم يختلف إلا.">
                    </a>
    </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D9%85%D8%AC%D8%A7%D9%87%D8%AF%D8%AA%D9%87-%D9%87%D8%B0%D9%87-%D8%B1%D8%A8%D9%85%D8%A7-%D9%83%D8%A7%D9%86%D8%AA-%D8%AA%D8%BA%D9%8A%D8%A8-%D8%B9%D9%86-%D8%B0%D9%83%D8%B1%D9%87-%D9%88%D9%81%D9%83%D8%B1%D9%87-%D8%AC%D9%85%D9%8A%D8%B9-%D8%A7%D9%84%D8%A3%D8%B4%D9%8A%D8%A7%D8%A1-%D8%A5%D9%84%D8%A7-3"> <p>على خلافه. وذلك أنه قال:...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">نشر بواسطة<a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
                    <li>
                <div class="sg-post small-post post-style-1">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D9%88%D8%B5%D9%84-%D8%A7%D9%84%D8%AD%D8%AC%D8%B1-%D8%A5%D9%84%D9%89-%D8%AD%D8%AF-%D9%85%D8%A7-%D9%85%D9%86-%D8%A7%D9%84%D9%86%D8%B8%D8%B1-%D8%A7%D9%84%D8%B9%D9%82%D9%84%D9%8A-%D9%88%D9%84%D8%A7%D8%AD-%D9%84%D9%87-%D9%85%D8%AB%D9%84-%D9%87%D8%B0%D9%87-4">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140314_small_123x83_43.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="لا سبيل لخطور ذلك الآمر على حقيقته لاعرضوا عن هذه البواطل، وأقبلو على الحق، واستغنوا عن هذا الرأي، ولا يسعى لغيره في.">
                    </a>
    </div>
    </div>
                    <div class="entry-content">
                       <a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/story/%D9%88%D8%B5%D9%84-%D8%A7%D9%84%D8%AD%D8%AC%D8%B1-%D8%A5%D9%84%D9%89-%D8%AD%D8%AF-%D9%85%D8%A7-%D9%85%D9%86-%D8%A7%D9%84%D9%86%D8%B8%D8%B1-%D8%A7%D9%84%D8%B9%D9%82%D9%84%D9%8A-%D9%88%D9%84%D8%A7%D8%AD-%D9%84%D9%87-%D9%85%D8%AB%D9%84-%D9%87%D8%B0%D9%87-4"> <p>لا سبيل لخطور ذلك الآمر ع...</p></a>
                        <div class="entry-meta">
                            <ul class="global-list">
                                <li class="d-sm-none d-md-none d-lg-block">نشر بواسطة<a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/author-profile/1"> Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/ar/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
            </ul>
</div>
                    <div class="sg-widget widget-social">
    <h3 class="widget-title">ابق على اتصال</h3>
    <div class="sg-socail">
        <ul class="global-list">
                            <li class="facebook"><a href="#" style="background:#056ED8" name="Facebook"><span style="background:#0061C2"><i class="fa fa-facebook" aria-hidden="true"></i></span>Facebook</a></li>
                            <li class="facebook"><a href="#" style="background:#E50017" name="Youtube"><span style="background:#FE031C"><i class="fa fa-youtube-play" aria-hidden="true"></i></span>Youtube</a></li>
                            <li class="facebook"><a href="#" style="background:#349AFF" name="Twitter"><span style="background:#2391FF"><i class="fa fa-twitter" aria-hidden="true"></i></span>Twitter</a></li>
                            <li class="facebook"><a href="#" style="background:#349affd9" name="Linkedin"><span style="background:#349AFF"><i class="fa fa-linkedin" aria-hidden="true"></i></span>Linkedin</a></li>
                            <li class="facebook"><a href="#" style="background:#4BA3FC" name="Skype"><span style="background:#4ba3fcd9"><i class="fa fa-skype" aria-hidden="true"></i></span>Skype</a></li>
                            <li class="facebook"><a href="#" style="background:#c2000dd9" name="Pinterest"><span style="background:#C2000D"><i class="fa fa-pinterest-square" aria-hidden="true"></i></span>Pinterest</a></li>
                    </ul>
    </div>
</div><!-- /.sg-widget -->
                    <div class="sg-widget">
    <h3 class="widget-title">النشرة الإخبارية</h3>
    <div class="widget-newsletter text-center">
        <div class="icon">
            <i class="fa fa-envelope-o" aria-hidden="true"></i>
        </div>
        <p>اشترك في قائمتنا البريدية للحصول على التحديثات الجديدة!</p>

        <form action="https://ohno-news-and-magazine-cms-laravel.dev/ar/newsletter/subscribe" class="tr-form" method="POST">
            <input type="hidden" name="_token" value="PFUTKWc5NIt7VTWjZEFvvrKuraGpPROV5ybrmMpF">            <label for="news" class="d-none">Newsletter</label>
            <input name="email" id="news" type="email" class="form-control" placeholder="عنوان البريد الإلكتروني" required>
            <button type="submit"><i class="fa fa-paper-plane" aria-hidden="true"></i><span class="d-none">عنوان البريد الإلكتروني</span></button>
        </form>
    </div>
</div>
    