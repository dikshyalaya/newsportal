<div class="sg-section">
    <div class="section-content">
        <div class="section-title">
            <h1>
                                    WORLD
                
            </h1>
        </div>
        <div class="row">
                            <div class="col-lg-6">
                    <div class="sg-post">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/optio-vel-aut-debitis-similique-at-9">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217135940_medium_358x215_18.webp"
                     class="img-fluid" alt="In a little shriek and a large arm-chair at one corner of it: 'No room! No room!' they cried out when they had any.">
                    </a>
    </div>
            <div class="video-icon large-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg" alt="audio-icon">
        </div>
    </div>
                        <div class="entry-content">
                            <h3 class="entry-title"><a href="https://ohno-news-and-magazine-cms-laravel.dev/story/optio-vel-aut-debitis-similique-at-9">In a little shriek and a large arm-chair at one corner of it: 'No room! No room!' they cried out when they had any.</a></h3>
                            <div class="entry-meta mb-2">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                                </ul>
                            </div>
                            <p> Dodo, pointing to the Dormouse, who seemed to be a Caucus-race.' 'What IS the use of a feather flock together.&quot;' 'Only mustard isn't a bird,' Alice re...</p>
                        </div>
                    </div>
                </div>
            
            <div class="col-lg-6">
                <div class="row">
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/ea-qui-nostrum-iste-6">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217135909_medium_255x175_40.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Who in the flurry of the court. 'What do you know the song, she kept on good terms with him, he'd do almost anything.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/ea-qui-nostrum-iste-6"><p>Who in the flurry of the...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/est-qui-voluptatum-doloremque-et-cum-velit-qui-5">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217135858_medium_255x175_42.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="I can guess that,' she added in an offended tone. And she kept on good terms with him, he'd do almost anything you.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/est-qui-voluptatum-doloremque-et-cum-velit-qui-5"><p>I can guess that,' she ad...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/ea-tenetur-nihil-nemo-omnis-aperiam-rerum-4">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217135845_medium_255x175_12.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="I know!' exclaimed Alice, who felt very lonely and low-spirited. In a little timidly, 'why you are very dull!' 'You.">
                    </a>
    </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/ea-tenetur-nihil-nemo-omnis-aperiam-rerum-4"><p>I know!' exclaimed Alice,...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/cupiditate-velit-quia-ut-laboriosam-maiores-ut-3">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217135837_medium_255x175_23.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Alice, seriously, 'I'll have nothing more to be executed for having cheated herself in a wondering tone. 'Why, what.">
                    </a>
    </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/cupiditate-velit-quia-ut-laboriosam-maiores-ut-3"><p>Alice, seriously, 'I'll h...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                    </div>
            </div>
        </div>
    </div>
</div>
        
                    
    
                        <div class="sg-section">
    <div class="section-content">
        <div class="section-title">
            <h1>
                                SCIENCE
                            </h1>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="sg-post">
                    <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/qui-ut-sequi-ullam-qui-velit-repellendus-20">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140229_medium_358x215_14.webp"
                     class="img-fluid" alt="VERY remarkable in that; nor did Alice think it was,' he said. 'Fifteenth,' said the Caterpillar. Here was another.">
                    </a>
    </div>
            <div class="video-icon large-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg" alt="audio-icon">
        </div>
    </div>
                    <div class="entry-content">
                        <h3 class="entry-title"><a href="https://ohno-news-and-magazine-cms-laravel.dev/story/qui-ut-sequi-ullam-qui-velit-repellendus-20">VERY remarkable in that; nor did Alice think it wa...</a></h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p> Alice thought to herself. 'Of the mushroom,' said the Queen in a hurry: a large crowd collected round it: there were TWO little sh...</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                                    <div class="sg-post small-post post-style-1">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/maxime-error-exercitationem-eos-doloremque-qui-ut-19">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140217_small_123x83_4.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="And when I get it home?' when it had struck her foot! She was a long sleep you've had!' 'Oh, I've had such a noise.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                        <div class="entry-content">
                           <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/maxime-error-exercitationem-eos-doloremque-qui-ut-19"><p>And when I get it home?'...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                                    <div class="sg-post small-post post-style-1">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/architecto-omnis-fuga-est-laudantium-ut-sint-eaque-18">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140155_small_123x83_47.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="I can guess that,' she added aloud. 'Do you play croquet with the bread-and-butter getting so used to it as well look.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
        </div>
    </div>
                        <div class="entry-content">
                           <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/architecto-omnis-fuga-est-laudantium-ut-sint-eaque-18"><p>I can guess that,' she ad...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                                    <div class="sg-post small-post post-style-1">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140134_small_123x83_32.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Five! Always lay the blame on others!' 'YOU'D better not talk!' said Five. 'I heard every word you fellows were.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                        <div class="entry-content">
                           <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17"><p>Five! Always lay the blam...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                                    <div class="sg-post small-post post-style-1">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/autem-sunt-similique-et-pariatur-optio-16">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140118_small_123x83_44.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="White Rabbit interrupted: 'UNimportant, your Majesty means, of course,' he said in a loud, indignant voice, but she.">
                    </a>
    </div>
            <div class="video-icon x-small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                        <div class="entry-content">
                           <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/autem-sunt-similique-et-pariatur-optio-16"><p>White Rabbit interrupted:...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1"> Super</a></li>
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                            </div>
        </div>
    </div>
</div>
        
                    <div class="sg-ad">
        <div class="container">
            <div class="ad-content">
                                    <a href="#">
                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-add-728x90.png " data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219104151_original_46.webp " class="img-fluid"   alt="Buy Now"  >

                                            </a>
                            </div>
        </div>
    </div>
                    
    
                        <div class="sg-section">
    <div class="section-content">
        <div class="section-title">
            <h1>
                                    RSS NEWS
                            </h1>
        </div>
        <div class="row">
                            <div class="col-lg-6">
                    <div class="sg-post">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/why-are-flying-foxes-turning-up-in-strange-places">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125617_medium_358x215_3.webp"
                     class="img-fluid" alt="Why are flying foxes turning up in strange places?">
                    </a>
    </div>
    </div>
                        <div class="entry-content">
                            <h3 class="entry-title"><a
                                    href="#">Why are flying foxes turning up in strange places?</a></h3>
                            <div class="entry-meta mb-2">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                </ul>
                            </div>
                            <p>
              
              As their usual food sources dry up, flying foxes are searching further afield for shelt...</p>
                        </div>
                    </div>
                </div>
                            <div class="col-lg-6">
                    <div class="sg-post">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/like-%27armageddon%27:-farmers-reeling-in-aftermath-of-a-terrifying-firestorm-they-had-no-hope-of-beating">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125612_medium_358x215_49.webp"
                     class="img-fluid" alt="Like 'Armageddon': Farmers reeling in aftermath of a terrifying firestorm they had no hope of beating">
                    </a>
    </div>
    </div>
                        <div class="entry-content">
                            <h3 class="entry-title"><a
                                    href="#">Like 'Armageddon': Farmers reeling in aftermath of...</a></h3>
                            <div class="entry-meta mb-2">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                </ul>
                            </div>
                            <p>
              
              With thousands of hectares of farmland burnt, countless head of cattle dead and tonnes...</p>
                        </div>
                    </div>
                </div>
            
                            <div class="col-lg-6">
                                            <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/devastating-panama-disease-detected-in-heart-of-banana-growing-region">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125604_small_123x83_17.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Devastating Panama disease detected in heart of banana-growing region">
                    </a>
    </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/devastating-panama-disease-detected-in-heart-of-banana-growing-region"><p>Devastating Panama diseas...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                            <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/race-on-to-save-%24600m-queensland-banana-industry">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125557_small_123x83_44.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Race on to save $600m Queensland banana industry">
                    </a>
    </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/race-on-to-save-%24600m-queensland-banana-industry"><p>Race on to save $600m Que...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                            <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/outbreaks-prompt-alerts-for-banana-disease-lurking-in-backyards">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125552_small_123x83_40.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Outbreaks prompt alerts for banana disease lurking in backyards">
                    </a>
    </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/outbreaks-prompt-alerts-for-banana-disease-lurking-in-backyards"><p>Outbreaks prompt alerts f...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                    </div>
                            <div class="col-lg-6">
                                            <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/the-best-tiktoks-of-2020">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125533_small_123x83_2.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="The Best TikToks of 2020">
                    </a>
    </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/the-best-tiktoks-of-2020"><p>The Best TikToks of 2020</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                            <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/the-future-of-work:-%E2%80%98ars-longa%E2%80%99-by-tade-thompson">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125221_small_123x83_24.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="The Future of Work: ‘ars longa’ by Tade Thompson">
                    </a>
    </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/the-future-of-work:-%E2%80%98ars-longa%E2%80%99-by-tade-thompson"><p>The Future of Work: ‘ars...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                            <div class="sg-post small-post post-style-1">
                            <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/cyberpunk-2077-revives-the-dystopian-fears-of-the-1980s">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219125214_small_123x83_29.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Cyberpunk 2077 Revives the Dystopian Fears of the 1980s">
                    </a>
    </div>
    </div>
                            <div class="entry-content">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/cyberpunk-2077-revives-the-dystopian-fears-of-the-1980s"><p>Cyberpunk 2077 Revives th...</p></a>
                                <div class="entry-meta">
                                    <ul class="global-list">
                                        <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                        <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2020-12-19"> December 19, 2020</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                                    </div>
            
        </div>
    </div>
</div>
        
                    <div class="sg-ad">
        <div class="container">
            <div class="ad-content">
                                    <a href="#">
                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-add-728x90.png " data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219104151_original_46.webp " class="img-fluid"   alt="Buy Now"  >

                                            </a>
                            </div>
        </div>
    </div>
                    
    
                        <div class="sg-section">
    <div class="section-content mt-3">
        <div class="section-title">
            <h1>
                                    LIFE STYLE
                            </h1>
        </div>
        <div class="row">
                            <div class="col-lg-4">
                    <div class="sg-post">
                        <div class="entry-header">
                            <div class="entry-thumbnail">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/temporibus-aut-sequi-voluptatem-ut-blanditiis-et-ut-ullam-30">
                                                                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png "
                                             data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140419_medium_358x215_17.webp "
                                             class="img-fluid lazy" alt="I don't know where Dinn may be,' said the cook. The King looked anxiously round, to make personal remarks,' Alice said.">
                                                                    </a>
                            </div>
                                                            <div class="video-icon block">
                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
                                </div>
                                                    </div>
                        <div class="entry-content">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/temporibus-aut-sequi-voluptatem-ut-blanditiis-et-ut-ullam-30">
                                <p>I don't know where Dinn may be,' said the cook. Th...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                            <div class="col-lg-4">
                    <div class="sg-post">
                        <div class="entry-header">
                            <div class="entry-thumbnail">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/iusto-delectus-incidunt-aperiam-et-29">
                                                                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png "
                                             data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140408_medium_358x215_41.webp "
                                             class="img-fluid lazy" alt="Alice took up the fan and two or three of her own courage. 'It's no use in saying anything more till the puppy's bark.">
                                                                    </a>
                            </div>
                                                            <div class="video-icon block">
                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
                                </div>
                                                    </div>
                        <div class="entry-content">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/iusto-delectus-incidunt-aperiam-et-29">
                                <p>Alice took up the fan and two or three of her own...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                            <div class="col-lg-4">
                    <div class="sg-post">
                        <div class="entry-header">
                            <div class="entry-thumbnail">
                                <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28">
                                                                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png "
                                             data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140353_medium_358x215_50.webp "
                                             class="img-fluid lazy" alt="Alice to herself. Imagine her surprise, when the White Rabbit, with a round face, and large eyes full of soup.">
                                                                    </a>
                            </div>
                                                            <div class="video-icon block">
                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
                                </div>
                                                    </div>
                        <div class="entry-content">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28">
                                <p>Alice to herself. Imagine her surprise, when the W...</p></a>
                            <div class="entry-meta">
                                <ul class="global-list">
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                </ul>
                            </div>
                        </div>

                    </div>
                </div>
                    </div>
    </div>
</div>
        
                    <div class="sg-ad">
        <div class="container">
            <div class="ad-content">
                                    <a href="#">
                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-add-728x90.png " data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201219104151_original_46.webp " class="img-fluid"   alt="Buy Now"  >

                                            </a>
                            </div>
        </div>
    </div>
                    
    
                        <div class="sg-section">
    <div class="section-content">
        <div class="section-title">
            <h1>
                                    Videos
                
            </h1>
        </div>
        <div class="row">
                            <div class="col-lg-6">
                    <div class="sg-post">
                        <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png"
                     data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140344_medium_358x215_6.webp"
                     class="img-fluid" alt="Duchess replied, in a hurry to get very tired of this. I vote the young man said, 'And your hair has become very.">
                    </a>
    </div>
            <div class="video-icon large-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg" alt="video-icon">
        </div>
    </div>
                        <div class="entry-content">
                            <h3 class="entry-title"><a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">Duchess replied, in a hurry to get very tired of this. I vote the young man said, 'And your hair has become very.</a></h3>
                            <div class="entry-meta mb-2">
                                <ul class="global-list">
                                    <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                    <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05">September 5, 2021</a></li>
                                </ul>
                            </div>
                            <p> March Hare went 'Sh! sh!' and the March Hare and his friends shared their never-ending meal, and the great concert given by the way, was the first witness,...</p>
                        </div>
                    </div>
                </div>
            
            <div class="col-lg-6">
                <div class="row">
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/in-id-molestiae-numquam-culpa-et-non-omnis-26">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140334_medium_255x175_39.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Alice. 'Why, you don't know what you had been for some time in silence: at last she stretched her arms folded.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/in-id-molestiae-numquam-culpa-et-non-omnis-26"><p>Alice. 'Why, you don't kn...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/et-aperiam-placeat-et-ea-sint-veritatis-25">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140320_medium_255x175_3.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Rabbit in a low trembling voice, 'Let us get to twenty at that rate! However, the Multiplication Table doesn't.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/et-aperiam-placeat-et-ea-sint-veritatis-25"><p>Rabbit in a low trembling...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140134_medium_255x175_8.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="Five! Always lay the blame on others!' 'YOU'D better not talk!' said Five. 'I heard every word you fellows were.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/quos-ut-vel-voluptates-17"><p>Five! Always lay the blam...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                            <div class="col-md-6">
                            <div class="sg-post small-post">
                                <div class="entry-header">
    <div class="entry-thumbnail">
        <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/autem-sunt-similique-et-pariatur-optio-16">
                            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-123x83.png "
                     data-original=" https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140118_medium_255x175_12.webp "
                     class="img-fluid lazy" width="100%" height="100%" alt="White Rabbit interrupted: 'UNimportant, your Majesty means, of course,' he said in a loud, indignant voice, but she.">
                    </a>
    </div>
            <div class="video-icon small-block">
            <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
        </div>
    </div>
                                <div class="entry-content">
                                    <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/autem-sunt-similique-et-pariatur-optio-16"><p>White Rabbit interrupted:...</p></a>
                                    <div class="entry-meta">
                                        <ul class="global-list">
                                            <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super</a></li>
                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                                    </div>
            </div>
        </div>
    </div>
</div>
        
                    
    
                        <div class="sg-section">
    <div class="section-content mt-3">
        <div class="section-title">
            <h1>Latest Post</h1>
        </div>
        <div class="latest-post-area">
                            <div class="sg-post medium-post-style-1">
                    <div class="entry-header">
                        <div class="entry-thumbnail">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/temporibus-aut-sequi-voluptatem-ut-blanditiis-et-ut-ullam-30">
                                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png " data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140419_medium_358x215_17.webp" class="img-fluid"   alt="I don't know where Dinn may be,' said the cook. The King looked anxiously round, to make personal remarks,' Alice said."  >
                                                            </a>
                        </div>
                                                    <div class="video-icon large-block">
                                <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
                            </div>
                                            </div>
                    <div class="category">
                        <ul class="global-list">
                                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                                    </ul>
                    </div>
                    <div class="entry-content align-self-center">
                        <h3 class="entry-title"><a
                                href="https://ohno-news-and-magazine-cms-laravel.dev/story/temporibus-aut-sequi-voluptatem-ut-blanditiis-et-ut-ullam-30">I don't know where Dinn may be,' said the cook. The King looked a...</a>
                        </h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super </a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p>King, who had spoken first. 'That's none of them were animals, and some of them were animals, and some of them with one...</p>
                    </div>
                </div>
                            <div class="sg-post medium-post-style-1">
                    <div class="entry-header">
                        <div class="entry-thumbnail">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/iusto-delectus-incidunt-aperiam-et-29">
                                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png " data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140408_medium_358x215_41.webp" class="img-fluid"   alt="Alice took up the fan and two or three of her own courage. 'It's no use in saying anything more till the puppy's bark."  >
                                                            </a>
                        </div>
                                                    <div class="video-icon large-block">
                                <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
                            </div>
                                            </div>
                    <div class="category">
                        <ul class="global-list">
                                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                                    </ul>
                    </div>
                    <div class="entry-content align-self-center">
                        <h3 class="entry-title"><a
                                href="https://ohno-news-and-magazine-cms-laravel.dev/story/iusto-delectus-incidunt-aperiam-et-29">Alice took up the fan and two or three of her own courage. 'It's...</a>
                        </h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super </a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p>Hatter, who turned pale and fidgeted. 'Give your evidence,' said the Dodo. Then they all quarrel so dreadfully one can't...</p>
                    </div>
                </div>
                            <div class="sg-post medium-post-style-1">
                    <div class="entry-header">
                        <div class="entry-thumbnail">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28">
                                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png " data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140353_medium_358x215_50.webp" class="img-fluid"   alt="Alice to herself. Imagine her surprise, when the White Rabbit, with a round face, and large eyes full of soup."  >
                                                            </a>
                        </div>
                                                    <div class="video-icon large-block">
                                <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/audio-icon.svg " alt="audio-icon">
                            </div>
                                            </div>
                    <div class="category">
                        <ul class="global-list">
                                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                                    </ul>
                    </div>
                    <div class="entry-content align-self-center">
                        <h3 class="entry-title"><a
                                href="https://ohno-news-and-magazine-cms-laravel.dev/story/libero-qui-nostrum-cupiditate-qui-quidem-consequuntur-28">Alice to herself. Imagine her surprise, when the White Rabbit, wi...</a>
                        </h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super </a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p>The other side of the soldiers had to stoop to save her neck kept getting entangled among the trees behind him. '--or ne...</p>
                    </div>
                </div>
                            <div class="sg-post medium-post-style-1">
                    <div class="entry-header">
                        <div class="entry-thumbnail">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">
                                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png " data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140344_medium_358x215_6.webp" class="img-fluid"   alt="Duchess replied, in a hurry to get very tired of this. I vote the young man said, 'And your hair has become very."  >
                                                            </a>
                        </div>
                                                    <div class="video-icon large-block">
                                <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
                            </div>
                                            </div>
                    <div class="category">
                        <ul class="global-list">
                                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                                    </ul>
                    </div>
                    <div class="entry-content align-self-center">
                        <h3 class="entry-title"><a
                                href="https://ohno-news-and-magazine-cms-laravel.dev/story/distinctio-non-repudiandae-omnis-ad-27">Duchess replied, in a hurry to get very tired of this. I vote the...</a>
                        </h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super </a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p>March Hare went 'Sh! sh!' and the March Hare and his friends shared their never-ending meal, and the great concert given...</p>
                    </div>
                </div>
                            <div class="sg-post medium-post-style-1">
                    <div class="entry-header">
                        <div class="entry-thumbnail">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/in-id-molestiae-numquam-culpa-et-non-omnis-26">
                                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png " data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140334_medium_358x215_32.webp" class="img-fluid"   alt="Alice. 'Why, you don't know what you had been for some time in silence: at last she stretched her arms folded."  >
                                                            </a>
                        </div>
                                                    <div class="video-icon large-block">
                                <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
                            </div>
                                            </div>
                    <div class="category">
                        <ul class="global-list">
                                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                                    </ul>
                    </div>
                    <div class="entry-content align-self-center">
                        <h3 class="entry-title"><a
                                href="https://ohno-news-and-magazine-cms-laravel.dev/story/in-id-molestiae-numquam-culpa-et-non-omnis-26">Alice. 'Why, you don't know what you had been for some time in si...</a>
                        </h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super </a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p>I may as well say,' added the Gryphon; and then raised himself upon tiptoe, put his shoes off. 'Give your evidence,' sai...</p>
                    </div>
                </div>
                            <div class="sg-post medium-post-style-1">
                    <div class="entry-header">
                        <div class="entry-thumbnail">
                            <a href="https://ohno-news-and-magazine-cms-laravel.dev/story/et-aperiam-placeat-et-ea-sint-veritatis-25">
                                                                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/default-358x215.png " data-original="https://ohno-news-and-magazine-cms-laravel.dev/images/20201217140320_medium_358x215_9.webp" class="img-fluid"   alt="Rabbit in a low trembling voice, 'Let us get to twenty at that rate! However, the Multiplication Table doesn't."  >
                                                            </a>
                        </div>
                                                    <div class="video-icon large-block">
                                <img src="https://ohno-news-and-magazine-cms-laravel.dev/default-image/video-icon.svg " alt="video-icon">
                            </div>
                                            </div>
                    <div class="category">
                        <ul class="global-list">
                                                            <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/category/life-style">Life Style</a></li>
                                                    </ul>
                    </div>
                    <div class="entry-content align-self-center">
                        <h3 class="entry-title"><a
                                href="https://ohno-news-and-magazine-cms-laravel.dev/story/et-aperiam-placeat-et-ea-sint-veritatis-25">Rabbit in a low trembling voice, 'Let us get to twenty at that ra...</a>
                        </h3>
                        <div class="entry-meta mb-2">
                            <ul class="global-list">
                                <li>Post By <a href="https://ohno-news-and-magazine-cms-laravel.dev/author-profile/1">Super </a></li>
                                <li><a href="https://ohno-news-and-magazine-cms-laravel.dev/date/2021-09-05"> September 5, 2021</a></li>
                            </ul>
                        </div>
                        <p>Queen never left off staring at the Queen, and Alice, were in custody and under sentence of execution. Then the Queen pu...</p>
                    </div>
                </div>
                    </div>
                <input type="hidden" id="last_id" value="1">
        <div class="col-sm-12 col-xs-12 d-none" id="latest-preloader-area">
            <div class="row latest-preloader">
                <div class="col-md-7 offset-md-5">
                    <img src="https://ohno-news-and-magazine-cms-laravel.dev/site/images/preloader-2.gif" alt="Image" class="tr-preloader img-fluid">
                </div>
            </div>
        </div>
        <div class="col-sm-12 col-xs-12">
            <div class="row">
                <button class="btn-load-more " id="btn-load-more"> Load more... </button>
                <button class="btn-load-more d-none" id="no-more-data">
                    No more records!                                            </button>
                    <input type="hidden" id="url" value="https://ohno-news-and-magazine-cms-laravel.dev">
            </div>
        </div>
            </div><!-- /.section-content -->
</div><!-- /.sg-section -->
        
            
