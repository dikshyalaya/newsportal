<div class="sg-widget">
    <h3 class="widget-title">{{ data_get($detail, 'title') }}</h3>

    {!! strip_tags(data_get($detail, 'content')) !!}
</div>

