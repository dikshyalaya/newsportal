<div class="row mb-4">
    <div class="col-lg-6 order-lg-6">
        <div class="thumb">
            <img class="img-fluid" src="{{ static_asset('default-image/default-358x215.png') }}" alt="Image">
        </div>
    </div>
    <div class="col-lg-6">
        <div class="text">
            <p class="paragraph">There are many variations of passages of Lorem Ipsum available, but the majority have suffered  believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of to use a passage of Lorem Ipsum, you </p>
        </div>
    </div>
</div>
