<div class="thumb mb-4">
    {!! $content['twitter-embed'][0]['twitter'] !!}
</div>
