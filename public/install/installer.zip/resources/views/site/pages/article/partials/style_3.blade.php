<div class="row mb-4">
    <div class="col-lg-4">
        <div class="text">
            <p class="paragraph">There are many variations of passages of Lorem Ipsum available, but the majority have suffered  believable. If you are going to use a passage of Lorem Ipsum, </p>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="thumb">
            <img class="img-fluid" src="{{ static_asset('default-image/default-255x175.png') }}" width="100%" alt="Image">
        </div>
    </div>
    <div class="col-lg-4">
        <div class="text">
            <p class="paragraph">There are many variations of passages of Lorem Ipsum available, but the majority have suffered  believable. If you are going to use a passage </p>
        </div>
    </div>
</div>
