<div class="row mb-4">
    <div class="text mx-3">
        <p class="paragraph">{!! @$content['text'][0]['text'] !!} </p>
    </div>
</div>
